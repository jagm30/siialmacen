<?php return array (
  'producto-component' => 'App\\Http\\Livewire\\ProductoComponent',
);
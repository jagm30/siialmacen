<div class="row">
    <div class="col-xs-12">
      <div class="box">
          <div class="box-header">
            <h3 class="box-title">Becas</h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
             <table id="example1" class="table table-bordered table-striped">           
		        <thead>                  
		          <tr>                    
		            <th scope="col">Id</th>                    
		            <th scope="col">Nombre</th>                    
		            <th scope="col">Descripción</th>   
		            <th scope="col">Categoria</th>                    
		            <th scope="col">Precio</th>                    
		            <th scope="col">Precio con descuento</th>                    
		            <th scope="col">Acción</th>                    
		            <th scope="col"></th>                  
		            </tr>                
		        </thead>                
		        <tbody>                    
		          <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
		            <tr>                            
		              <td><?php echo e($producto->id); ?></td>                            
		              <td><?php echo e($producto->nombre); ?></td>                            
		              <td><?php echo e($producto->descripcion); ?></td>
		              <td><?php echo e($producto->categoria); ?></td>                            
		              <td><?php echo e($producto->precio); ?></td>                            
		              <td>$<?php echo e($producto->precioPromocion); ?> MXN</td>                            
		              <td>                                
		                <button type="button" class="btn btn-success">Editar</button>                            
		              </td>                            
		              <td>                                
		                <button type="button" class="btn btn-danger">Borrar</button>                            
		              </td>                        
		            </tr>                    
		          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
		        </tbody>            
		       </table>     
		       <style type="text/css">.dataTables_paginate a.paginate_button.previous {display: none;}</style>        
		       <?php echo e($productos->links('pagination::Bootstrap-4')); ?>      
          </div>
          <!-- /.box-body -->
        </div>
    </div>
  </div><?php /**PATH D:\xampp\htdocs\siiconsultorio\resources\views/livewire/producto-component.blade.php ENDPATH**/ ?>